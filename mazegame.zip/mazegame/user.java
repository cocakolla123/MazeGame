import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.* ;
//import java.util.List; 
//import java.util.ArrayList;
/**
 * Write a description of class user here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class user extends Actor
{
        int personVal = 2;
        int count = 0;
        ArrayList<String> questions = new ArrayList<String>();
        ArrayList<String> answers = new ArrayList<String>();
        public boolean win = false;
        

    /**
     * Act - do whatever the user wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public boolean getWin() {
        return win;
    }
    protected user() {
        questions.add( "2 + 2" );
        questions.add( "3 + 7" );
        questions.add( "4 + 5" );
        answers.add("4");
        answers.add("10");
        answers.add("9");
        setImage(new GreenfootImage("images/ppl1.png"));
    }
    public void act() 
    {
    
    /*    
    int dx=0, dy=0;
        if (Greenfoot.isKeyDown("up")) dy--;
        if (Greenfoot.isKeyDown("down")) dy++;
        if (Greenfoot.isKeyDown("right")) dx++;
        if (Greenfoot.isKeyDown("left")) dx--;
        if (dx != 0 || dy != 0) setLocation(getX()+dx, getY()+dy);
    */
    if (Greenfoot.isKeyDown("left")) {
        if (!checkForOtherWall('l')) {
            setLocation(getX() - personVal, getY());
        }
    }
    if (Greenfoot.isKeyDown("right")) {
        if (!checkForOtherWall('r')) {
            setLocation(getX() + personVal, getY());
        }
    }
    if (Greenfoot.isKeyDown("up")) {
        if (!checkForOtherWall('u')) {
            setLocation(getX(), getY() - personVal);
        }
    }
    if (Greenfoot.isKeyDown("down")) {
        if (!checkForOtherWall('d')) {
            setLocation(getX(), getY() + personVal);
        }
    }
    cherryTouch();
    exit();
    
}
    
    public boolean checkForOtherWall(char dir) {
        wall w = null;
        wallTwo w2 = null;
        if (dir == 'l') {
            w2 = (wallTwo) getOneObjectAtOffset(-personVal, 0, wallTwo.class);
            w = (wall) getOneObjectAtOffset(-personVal, 0, wall.class);
        }
        if (dir == 'r') {
            w2 = (wallTwo) getOneObjectAtOffset(personVal, 0, wallTwo.class);
            w = (wall) getOneObjectAtOffset(personVal, 0, wall.class);
        }
        if (dir == 'd') {
            w = (wall) getOneObjectAtOffset(0, personVal, wall.class);
            w2 = (wallTwo) getOneObjectAtOffset(0, personVal, wallTwo.class);
        }
        if (dir == 'u') {
            w = (wall) getOneObjectAtOffset(0,-personVal , wall.class);
            w2 = (wallTwo) getOneObjectAtOffset(0,-personVal , wallTwo.class);
        }
        
        if (w != null || w2 != null) {
            return true;
        } 
            
        return false;
        
    }
    
    public void cherryTouch() {
       question c = (question) getOneIntersectingObject(question.class); 
       
       int rand = Greenfoot.getRandomNumber(questions.size());
       if (c != null) {
           String q = Greenfoot.ask(questions.get(rand));
           if (q.contains(answers.get(rand))) {
               getWorld().removeObject(c);
               questions.remove(rand);
               answers.remove(rand);
               count ++;
            } else {
                Greenfoot.setWorld(new myWorld());
            }
           
        }
    

    }
    
    
    
    public void exit()  {
        Exit exit = (Exit) getOneIntersectingObject(Exit.class);
        if (exit != null && count == 2) {
            win = true;
            System.out.println(win);
            getWorld().removeObject(exit);
            setImage(new GreenfootImage("you-win-lettering-pop-art-text-banner_185004-60.jpg"));
            setLocation(612, 404);
            win = false;
            //Greenfoot.setWorld(new myWorld());
        }
        
    }
}





