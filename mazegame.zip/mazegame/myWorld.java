import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class myWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class myWorld extends World
{
    public static wall w1 = new wall();
    public static wallTwo w2 = new wallTwo();
    public static user player = new user();
    public static Exit exit = new Exit();
    public static question q = new question();
    

    /**
     * Constructor for objects of class myWorld.
     * 
     */
    
    public myWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1200, 800, 1); 
        
        addObject(new wallTwo(), 126, 712);
        addObject(new wallTwo(), 126, 542);
        addObject(new wallTwo(), 459, 544);
        addObject(new wallTwo(), 353, 237);
        addObject(new wallTwo(), 244, 237);
        addObject(new wallTwo(), 596, 543);
        addObject(new wall(), 292, 436);
        addObject(new wall(), 562, 306);
        addObject(new wall(), 409, 54);
        addObject(new wall(), 762, 435);
        addObject(new wall(), 762, 741);
        addObject(new wall(), 762, 648);
        addObject(new question(), 200, 200);
        addObject(new question(), 400, 200);
        addObject(new Exit(), 1150, 750);
        addObject(player, 50, 750);
    }
    
   
  
    
   
}
